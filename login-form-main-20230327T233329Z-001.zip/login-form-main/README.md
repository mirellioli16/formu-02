# Login Form

This is a simple and responsive login form made with HTML and CSS using transitions.<br />
This project was made for a youtube tutorial.<br /><br/>
**Youtube link: https://youtu.be/MkXuQ9CcHqU**
### Final Result
<img src="assets/final.png" alt="Web Version"/>

## 🚀 Starting

To start the project, just open the file `index.html` in your preferred browser.

---
##### Coded with love by Giovanna Moeller ♥️